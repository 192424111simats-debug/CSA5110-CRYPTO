import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const Topbar = ({ title }: { title: string }) => {
  const { user } = useAuth();

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 shadow-sm">
      <h1 className="text-xl font-semibold text-gray-800">{title}</h1>
      <div className="flex items-center gap-4">
        <div className="text-sm text-gray-600">
          <span className="font-medium text-gray-900">{user?.username}</span>
          <span className="mx-2 text-gray-300">|</span>
          <span className="bg-brand-100 text-brand-700 px-2 py-1 rounded text-xs font-semibold">
            {user?.role}
          </span>
        </div>
      </div>
    </header>
  );
};

export default Topbar;

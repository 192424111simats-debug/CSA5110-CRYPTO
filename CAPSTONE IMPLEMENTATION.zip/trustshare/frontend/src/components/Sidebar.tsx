import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LayoutDashboard, Folder, Share2, Upload, Activity, Users, Settings, LogOut } from 'lucide-react';

const Sidebar = () => {
  const { user, logout } = useAuth();

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'My Files', path: '/files', icon: Folder },
    { name: 'Shared With Me', path: '/shared', icon: Share2 },
    { name: 'Upload', path: '/upload', icon: Upload },
  ];

  const adminItems = [
    { name: 'Activity Logs', path: '/admin/logs', icon: Activity },
    { name: 'Users', path: '/admin/users', icon: Users },
  ];

  return (
    <div className="w-64 bg-surface-dark text-white h-screen flex flex-col fixed left-0 top-0">
      <div className="p-6 font-bold text-xl tracking-wider text-brand-100">
        TrustShare
      </div>
      <nav className="flex-1 px-4 space-y-2 mt-4">
        {navItems.map(item => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center px-4 py-3 rounded-md transition-colors ${
                isActive ? 'bg-brand-700 text-white' : 'text-gray-300 hover:bg-gray-800'
              }`
            }
          >
            <item.icon className="w-5 h-5 mr-3" />
            {item.name}
          </NavLink>
        ))}

        {user?.role === 'Admin' && (
          <>
            <div className="mt-8 mb-2 px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Administration
            </div>
            {adminItems.map(item => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center px-4 py-3 rounded-md transition-colors ${
                    isActive ? 'bg-brand-700 text-white' : 'text-gray-300 hover:bg-gray-800'
                  }`
                }
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </NavLink>
            ))}
          </>
        )}
      </nav>
      <div className="p-4 border-t border-gray-800 space-y-2">
        <NavLink to="/settings" className="flex items-center px-4 py-3 text-gray-300 hover:bg-gray-800 rounded-md">
          <Settings className="w-5 h-5 mr-3" />
          Settings
        </NavLink>
        <button
          onClick={logout}
          className="flex items-center w-full px-4 py-3 text-gray-300 hover:bg-gray-800 rounded-md"
        >
          <LogOut className="w-5 h-5 mr-3" />
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;

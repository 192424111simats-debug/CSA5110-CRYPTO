import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';
import api from '../api';

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    myFiles: 0,
    sharedWithMe: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [myFilesRes, sharedRes] = await Promise.all([
          api.get('/files/mine'),
          api.get('/files/shared-with-me')
        ]);
        setStats({
          myFiles: myFilesRes.data.length,
          sharedWithMe: sharedRes.data.length,
        });
      } catch (err) {
        console.error("Failed to fetch stats", err);
      }
    };
    fetchStats();
  }, []);

  return (
    <Layout title="Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-gray-500 text-sm font-medium uppercase tracking-wider">My Files</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">{stats.myFiles}</p>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-gray-500 text-sm font-medium uppercase tracking-wider">Shared With Me</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">{stats.sharedWithMe}</p>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-8 text-center">
        <h2 className="text-xl font-medium text-gray-800 mb-2">Welcome to TrustShare</h2>
        <p className="text-gray-500 max-w-lg mx-auto">
          Your secure, E2E encrypted file sharing platform. Navigate using the sidebar to upload new files, 
          manage your existing ones, or view files shared with you by others.
        </p>
      </div>
    </Layout>
  );
};

export default Dashboard;

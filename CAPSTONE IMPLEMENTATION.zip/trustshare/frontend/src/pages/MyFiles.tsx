import React, { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import api from '../api';
import toast from 'react-hot-toast';
import { format } from 'date-fns';
import { Download, Share2, Shield, ShieldAlert, Trash2 } from 'lucide-react';

interface FileData {
  _id: string;
  filename: string;
  size: number;
  createdAt: string;
}

const MyFiles = () => {
  const [files, setFiles] = useState<FileData[]>([]);
  const [loading, setLoading] = useState(true);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<FileData | null>(null);
  
  // Share form
  const [recipientEmail, setRecipientEmail] = useState('');
  const [password, setPassword] = useState('');
  const [shareLoading, setShareLoading] = useState(false);

  // Download form
  const [downloadModalOpen, setDownloadModalOpen] = useState(false);
  const [downloadPassword, setDownloadPassword] = useState('');
  const [downloadLoading, setDownloadLoading] = useState(false);

  useEffect(() => {
    fetchFiles();
  }, []);

  const fetchFiles = async () => {
    try {
      const res = await api.get('/files/mine');
      setFiles(res.data);
    } catch (error) {
      toast.error('Failed to fetch files');
    } finally {
      setLoading(false);
    }
  };

  const openShare = (file: FileData) => {
    setSelectedFile(file);
    setRecipientEmail('');
    setPassword('');
    setShareModalOpen(true);
  };

  const handleShare = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;
    setShareLoading(true);
    try {
      await api.post(`/files/${selectedFile._id}/share`, {
        email: recipientEmail,
        password
      });
      toast.success('File shared successfully');
      setShareModalOpen(false);
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Share failed');
    } finally {
      setShareLoading(false);
    }
  };

  const openDownload = (file: FileData) => {
    setSelectedFile(file);
    setDownloadPassword('');
    setDownloadModalOpen(true);
  };

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;
    setDownloadLoading(true);
    try {
      const res = await api.get(`/files/${selectedFile._id}/download`, {
        headers: { 'X-Password': downloadPassword },
        responseType: 'blob'
      });
      
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', selectedFile.filename);
      document.body.appendChild(link);
      link.click();
      link.parentNode?.removeChild(link);
      
      toast.success('File decrypted and verified successfully');
      setDownloadModalOpen(false);
    } catch (err: any) {
      toast.error('Download failed. Incorrect password or integrity error.');
    } finally {
      setDownloadLoading(false);
    }
  };

  return (
    <Layout title="My Files">
      {loading ? (
        <div className="text-gray-500">Loading...</div>
      ) : files.length === 0 ? (
        <div className="bg-white p-8 rounded-lg border border-gray-200 shadow-sm text-center text-gray-500">
          You haven't uploaded any files yet.
        </div>
      ) : (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">File Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Size</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {files.map(file => (
                <tr key={file._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{file.filename}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{(file.size / 1024).toFixed(1)} KB</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{format(new Date(file.createdAt), 'MMM d, yyyy HH:mm')}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-3">
                    <button onClick={() => openShare(file)} className="text-brand-600 hover:text-brand-900 inline-flex items-center">
                      <Share2 className="w-4 h-4 mr-1" /> Share
                    </button>
                    <button onClick={() => openDownload(file)} className="text-brand-600 hover:text-brand-900 inline-flex items-center">
                      <Download className="w-4 h-4 mr-1" /> Download
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Share Modal */}
      {shareModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Share {selectedFile?.filename}</h3>
            <form onSubmit={handleShare} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Recipient Email</label>
                <input type="email" required className="input-field mt-1" value={recipientEmail} onChange={e => setRecipientEmail(e.target.value)} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Your Password</label>
                <input type="password" required className="input-field mt-1" value={password} onChange={e => setPassword(e.target.value)} />
                <p className="text-xs text-gray-500 mt-1">Required to decrypt your private key and re-wrap the AES key for the recipient.</p>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button type="button" onClick={() => setShareModalOpen(false)} className="btn-secondary">Cancel</button>
                <button type="submit" disabled={shareLoading} className="btn-primary">{shareLoading ? 'Sharing...' : 'Share'}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Download Modal */}
      {downloadModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Download {selectedFile?.filename}</h3>
            <form onSubmit={handleDownload} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Your Password</label>
                <input type="password" required className="input-field mt-1" value={downloadPassword} onChange={e => setDownloadPassword(e.target.value)} />
                <p className="text-xs text-gray-500 mt-1">Required to decrypt your private key and unwrap the file's AES key.</p>
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button type="button" onClick={() => setDownloadModalOpen(false)} className="btn-secondary">Cancel</button>
                <button type="submit" disabled={downloadLoading} className="btn-primary">{downloadLoading ? 'Decrypting...' : 'Download'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default MyFiles;

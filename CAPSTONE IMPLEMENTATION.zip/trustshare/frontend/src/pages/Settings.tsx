import React from 'react';
import Layout from '../components/Layout';
import { useAuth } from '../contexts/AuthContext';

const Settings = () => {
  const { user } = useAuth();

  return (
    <Layout title="Settings">
      <div className="max-w-2xl">
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-6">Profile Information</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-500">Username</label>
              <p className="mt-1 text-sm text-gray-900">{user?.username}</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-500">Email</label>
              <p className="mt-1 text-sm text-gray-900">{user?.email}</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-500">Role</label>
              <p className="mt-1 text-sm text-gray-900">{user?.role}</p>
            </div>
          </div>
          <p className="mt-6 text-xs text-gray-400">
            Cryptographic keys and password hashes are never exposed in the UI for security.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;

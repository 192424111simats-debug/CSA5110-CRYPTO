import React, { useState, useRef } from 'react';
import Layout from '../components/Layout';
import toast from 'react-hot-toast';
import api from '../api';
import { UploadCloud, CheckCircle, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Upload = () => {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'uploading' | 'encrypting' | 'success' | 'error'>('idle');
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      if (e.target.files[0].size > 100 * 1024 * 1024) {
        toast.error('File exceeds 100MB limit');
        return;
      }
      setFile(e.target.files[0]);
      setStatus('idle');
      setProgress(0);
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setStatus('uploading');
    
    const formData = new FormData();
    formData.append('file', file);

    try {
      await api.post('/files/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent) => {
          if (progressEvent.total) {
            const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setProgress(percentCompleted);
            if (percentCompleted === 100) {
              setStatus('encrypting');
            }
          }
        }
      });
      setStatus('success');
      toast.success('File uploaded and encrypted successfully');
      setTimeout(() => navigate('/files'), 1500);
    } catch (err: any) {
      console.error(err);
      setStatus('error');
      toast.error(err.response?.data?.message || 'Upload failed');
    }
  };

  return (
    <Layout title="Upload File">
      <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg border border-gray-200 shadow-sm mt-8">
        <div 
          className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:bg-gray-50 transition-colors cursor-pointer"
          onClick={() => fileInputRef.current?.click()}
        >
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            onChange={handleFileChange}
          />
          <UploadCloud className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          {file ? (
            <p className="text-gray-900 font-medium">{file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)</p>
          ) : (
            <>
              <p className="text-gray-700 font-medium">Click to select or drag and drop a file</p>
              <p className="text-sm text-gray-500 mt-1">Any file up to 100MB</p>
            </>
          )}
        </div>

        {file && (
          <div className="mt-8">
            <button
              onClick={handleUpload}
              disabled={status === 'uploading' || status === 'encrypting' || status === 'success'}
              className="w-full btn-primary py-3"
            >
              {status === 'idle' && 'Start Secure Upload'}
              {status === 'uploading' && `Uploading... ${progress}%`}
              {status === 'encrypting' && 'Server encrypting...'}
              {status === 'success' && 'Done'}
              {status === 'error' && 'Retry Upload'}
            </button>

            {status !== 'idle' && (
              <div className="mt-6 space-y-4">
                <div className="flex items-center text-sm">
                  {progress > 0 ? <CheckCircle className="w-4 h-4 text-green-500 mr-2" /> : <div className="w-4 h-4 rounded-full border-2 border-brand-500 border-t-transparent animate-spin mr-2" />}
                  <span className={progress > 0 ? 'text-gray-900' : 'text-gray-500'}>1. Uploading to server</span>
                </div>
                <div className="flex items-center text-sm">
                  {status === 'success' ? <CheckCircle className="w-4 h-4 text-green-500 mr-2" /> : 
                   status === 'encrypting' ? <div className="w-4 h-4 rounded-full border-2 border-brand-500 border-t-transparent animate-spin mr-2" /> :
                   <div className="w-4 h-4 rounded-full border-2 border-gray-200 mr-2" />}
                  <span className={status === 'success' ? 'text-gray-900' : status === 'encrypting' ? 'text-gray-900' : 'text-gray-500'}>
                    2. Server-side AES-GCM encryption & SHA-256 integrity check
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Upload;

import crypto from 'crypto';
import { promisify } from 'util';

const scrypt = promisify(crypto.scrypt);

// RSA Key Generation
export const generateRSAKeyPair = () => {
  return crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
};

// Derive key using scrypt
export const deriveKey = async (password: string, salt: Buffer): Promise<Buffer> => {
  return (await scrypt(password, salt, 32)) as Buffer;
};

// Encrypt Private Key with User's Password
export const encryptPrivateKey = async (privateKeyPEM: string, password: string) => {
  const salt = crypto.randomBytes(16);
  const key = await deriveKey(password, salt);
  const iv = crypto.randomBytes(12);
  
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  let encrypted = cipher.update(privateKeyPEM, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  const authTag = cipher.getAuthTag();

  return {
    encryptedPrivateKey: encrypted,
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64')
  };
};

// Decrypt Private Key
export const decryptPrivateKey = async (
  encryptedPrivateKey: string,
  saltBase64: string,
  ivBase64: string,
  authTagBase64: string,
  password: string
) => {
  const salt = Buffer.from(saltBase64, 'base64');
  const iv = Buffer.from(ivBase64, 'base64');
  const authTag = Buffer.from(authTagBase64, 'base64');
  const key = await deriveKey(password, salt);

  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  
  let decrypted = decipher.update(encryptedPrivateKey, 'base64', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
};

// Generate Random AES Key
export const generateAESKey = () => crypto.randomBytes(32);

// Wrap AES Key with RSA Public Key
export const wrapKey = (aesKey: Buffer, rsaPublicKeyPEM: string) => {
  return crypto.publicEncrypt(
    {
      key: rsaPublicKeyPEM,
      padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
      oaepHash: 'sha256',
    },
    aesKey
  ).toString('base64');
};

// Unwrap AES Key with RSA Private Key
export const unwrapKey = (wrappedKeyBase64: string, rsaPrivateKeyPEM: string) => {
  return crypto.privateDecrypt(
    {
      key: rsaPrivateKeyPEM,
      padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
      oaepHash: 'sha256',
    },
    Buffer.from(wrappedKeyBase64, 'base64')
  );
};

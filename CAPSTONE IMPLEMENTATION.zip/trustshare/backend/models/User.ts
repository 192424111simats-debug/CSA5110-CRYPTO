import mongoose, { Schema, Document } from 'mongoose';

export interface IUser extends Document {
  username: string;
  email: string;
  passwordHash: string;
  role: 'User' | 'Admin';
  rsaPublicKey: string; // Stored in plain
  encryptedPrivateKey: string; // Encrypted with AES-GCM (scrypt derived key)
  privateKeySalt: string;
  privateKeyIV: string;
  privateKeyAuthTag: string;
  createdAt: Date;
}

const UserSchema: Schema = new Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['User', 'Admin'], default: 'User' },
  rsaPublicKey: { type: String, required: true },
  encryptedPrivateKey: { type: String, required: true },
  privateKeySalt: { type: String, required: true },
  privateKeyIV: { type: String, required: true },
  privateKeyAuthTag: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model<IUser>('User', UserSchema);

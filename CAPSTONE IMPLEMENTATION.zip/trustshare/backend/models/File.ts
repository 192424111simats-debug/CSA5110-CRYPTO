import mongoose, { Schema, Document } from 'mongoose';

export interface IWrappedKey {
  userId: mongoose.Types.ObjectId;
  wrappedKey: string; // RSA-OAEP encrypted AES key
}

export interface IFile extends Document {
  owner: mongoose.Types.ObjectId;
  filename: string;
  mimeType: string;
  size: number;
  encryptedBlobReference: string; // UUID filename on disk
  wrappedAESKeys: IWrappedKey[];
  iv: string; // AES-GCM IV for the file
  authTag: string; // AES-GCM Auth Tag for the file
  sha256Hash: string; // SHA-256 of the *original* plaintext
  createdAt: Date;
}

const FileSchema: Schema = new Schema({
  owner: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  filename: { type: String, required: true },
  mimeType: { type: String, required: true },
  size: { type: Number, required: true },
  encryptedBlobReference: { type: String, required: true },
  wrappedAESKeys: [{
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    wrappedKey: { type: String, required: true }
  }],
  iv: { type: String, required: true },
  authTag: { type: String, required: true },
  sha256Hash: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model<IFile>('File', FileSchema);

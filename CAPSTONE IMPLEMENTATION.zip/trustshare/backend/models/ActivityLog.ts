import mongoose, { Schema, Document } from 'mongoose';

export interface IActivityLog extends Document {
  userId: mongoose.Types.ObjectId | null;
  action: 'LOGIN' | 'LOGIN_FAILED' | 'UPLOAD' | 'DOWNLOAD' | 'SHARE' | 'REVOKE_ACCESS' | 'ACCESS_DENIED' | 'INTEGRITY_CHECK' | 'INTEGRITY_FAILURE' | 'ROLE_CHANGED' | 'REGISTER';
  target: string;
  status: 'SUCCESS' | 'FAILURE';
  timestamp: Date;
  ip: string;
  metadata?: any;
}

const ActivityLogSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', default: null }, // Null for failed logins
  action: { type: String, required: true },
  target: { type: String, required: true },
  status: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  ip: { type: String, required: true },
  metadata: { type: Schema.Types.Mixed },
});

export default mongoose.model<IActivityLog>('ActivityLog', ActivityLogSchema);

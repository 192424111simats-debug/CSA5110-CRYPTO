import mongoose, { Schema, Document } from 'mongoose';

export interface IAccessGrant extends Document {
  fileId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  permission: 'view' | 'download';
  grantedBy: mongoose.Types.ObjectId;
  grantedAt: Date;
}

const AccessGrantSchema: Schema = new Schema({
  fileId: { type: Schema.Types.ObjectId, ref: 'File', required: true },
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  permission: { type: String, enum: ['view', 'download'], required: true },
  grantedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  grantedAt: { type: Date, default: Date.now },
});

export default mongoose.model<IAccessGrant>('AccessGrant', AccessGrantSchema);

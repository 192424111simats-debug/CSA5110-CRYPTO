import { Router, Response } from 'express';
import { AuthRequest, authenticateToken, requireRole } from '../middleware/auth';
import User from '../models/User';
import ActivityLog from '../models/ActivityLog';

const router = Router();

// Apply auth and admin check to all routes in this file
router.use(authenticateToken);
router.use(requireRole('Admin'));

router.get('/logs', async (req: AuthRequest, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    
    const logs = await ActivityLog.find()
      .sort({ timestamp: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('userId', 'username email');
      
    const total = await ActivityLog.countDocuments();
    
    res.json({ logs, total, page, limit });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching logs' });
  }
});

router.get('/users', async (req: AuthRequest, res: Response) => {
  try {
    const users = await User.find().select('-passwordHash -rsaPublicKey -encryptedPrivateKey -privateKeySalt -privateKeyIV -privateKeyAuthTag');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching users' });
  }
});

router.patch('/users/:id/role', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { role } = req.body;
    if (!['User', 'Admin'].includes(role)) {
      res.status(400).json({ message: 'Invalid role' });
      return;
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      res.status(404).json({ message: 'User not found' });
      return;
    }

    user.role = role;
    await user.save();

    await ActivityLog.create({
      userId: req.user?._id,
      action: 'ROLE_CHANGED',
      target: user._id.toString(),
      metadata: { newRole: role },
      status: 'SUCCESS',
      ip: req.ip || req.socket.remoteAddress
    });

    res.json({ message: 'Role updated successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating role' });
  }
});

export default router;

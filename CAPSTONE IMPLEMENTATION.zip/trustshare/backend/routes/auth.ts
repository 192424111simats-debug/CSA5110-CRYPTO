import { Router, Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/User';
import ActivityLog from '../models/ActivityLog';
import { generateRSAKeyPair, encryptPrivateKey } from '../utils/crypto';
import { AuthRequest, authenticateToken } from '../middleware/auth';

const router = Router();

router.post('/register', async (req: Request, res: Response): Promise<void> => {
  try {
    const { username, email, password } = req.body;
    
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      res.status(400).json({ message: 'User already exists' });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 12);
    
    // RSA KeyGen
    const { publicKey, privateKey } = generateRSAKeyPair();
    
    // Encrypt Private Key with User's Password
    const { encryptedPrivateKey, salt, iv, authTag } = await encryptPrivateKey(privateKey, password);

    // Initial admin check
    let role = 'User';
    if (process.env.INITIAL_ADMIN_EMAIL && email === process.env.INITIAL_ADMIN_EMAIL) {
      const adminCount = await User.countDocuments({ role: 'Admin' });
      if (adminCount === 0) {
        role = 'Admin';
      }
    }

    const newUser = new User({
      username,
      email,
      passwordHash,
      role,
      rsaPublicKey: publicKey,
      encryptedPrivateKey,
      privateKeySalt: salt,
      privateKeyIV: iv,
      privateKeyAuthTag: authTag
    });

    await newUser.save();
    
    await ActivityLog.create({
      userId: newUser._id,
      action: 'REGISTER',
      target: newUser.username,
      status: 'SUCCESS',
      ip: req.ip || req.socket.remoteAddress
    });

    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error during registration' });
  }
});

router.post('/login', async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    
    if (!user) {
      await ActivityLog.create({ action: 'LOGIN_FAILED', target: email, status: 'FAILURE', ip: req.ip || req.socket.remoteAddress });
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      await ActivityLog.create({ userId: user._id, action: 'LOGIN_FAILED', target: email, status: 'FAILURE', ip: req.ip || req.socket.remoteAddress });
      res.status(401).json({ message: 'Invalid credentials' });
      return;
    }

    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET as string, {
      expiresIn: process.env.JWT_EXPIRES_IN || '24h'
    });

    await ActivityLog.create({ userId: user._id, action: 'LOGIN', target: 'SYSTEM', status: 'SUCCESS', ip: req.ip || req.socket.remoteAddress });

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error during login' });
  }
});

router.get('/me', authenticateToken, (req: AuthRequest, res: Response) => {
  if (req.user) {
    res.json({
      id: req.user._id,
      username: req.user.username,
      email: req.user.email,
      role: req.user.role
    });
  }
});

export default router;

import { Router, Response } from 'express';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

import { AuthRequest, authenticateToken } from '../middleware/auth';
import File from '../models/File';
import User from '../models/User';
import AccessGrant from '../models/AccessGrant';
import ActivityLog from '../models/ActivityLog';

import {
  generateAESKey,
  wrapKey,
  unwrapKey,
  decryptPrivateKey,
} from '../utils/crypto';

const router = Router();

const upload = multer({
  dest: 'temp/',
  limits: {
    fileSize: 100 * 1024 * 1024,
  },
});

// ==========================================
// UPLOAD FILE
// ==========================================

router.post(
  '/upload',
  authenticateToken,
  upload.single('file'),
  async (req: AuthRequest, res: Response): Promise<void> => {
    const uploadedFile = req.file;

    if (!uploadedFile || !req.user) {
      res.status(400).json({
        message: 'No file uploaded or user not authenticated',
      });
      return;
    }

    try {
      // Generate AES-256 key
      const aesKey = generateAESKey();

      // Generate GCM IV
      const iv = crypto.randomBytes(12);

      // Generate secure storage reference
      const blobReference = uuidv4();

      const storagePath = path.resolve(
        process.env.STORAGE_PATH || './storage'
      );

      if (!fs.existsSync(storagePath)) {
        fs.mkdirSync(storagePath, {
          recursive: true,
        });
      }

      const finalFilePath = path.join(
        storagePath,
        blobReference
      );

      // Streams
      const readStream = fs.createReadStream(
        uploadedFile.path
      );

      const writeStream = fs.createWriteStream(
        finalFilePath
      );

      // AES-GCM cipher
      const cipher = crypto.createCipheriv(
        'aes-256-gcm',
        aesKey,
        iv
      );

      // SHA256 hash of plaintext
      const hash = crypto.createHash('sha256');

      const { Transform } = await import('stream');

      const hashThrough = new Transform({
        transform(chunk, _encoding, callback) {
          hash.update(chunk);
          callback(null, chunk);
        },
      });

      const { pipeline } = await import(
        'stream/promises'
      );

      // Plaintext -> Hash -> Encrypt -> Disk
      await pipeline(
        readStream,
        hashThrough,
        cipher,
        writeStream
      );

      // Get GCM authentication tag
      const authTag = cipher
        .getAuthTag()
        .toString('base64');

      // Get plaintext SHA256
      const sha256Hash = hash.digest('hex');

      // Wrap AES key using owner's RSA public key
      const wrappedKey = wrapKey(
        aesKey,
        req.user.rsaPublicKey
      );

      // Save metadata
      const newFile = new File({
        owner: req.user._id,
        filename: uploadedFile.originalname,
        mimeType: uploadedFile.mimetype,
        size: uploadedFile.size,
        encryptedBlobReference: blobReference,

        wrappedAESKeys: [
          {
            userId: req.user._id,
            wrappedKey,
          },
        ],

        iv: iv.toString('base64'),
        authTag,
        sha256Hash,
      });

      await newFile.save();

      // Remove plaintext temporary upload
      if (fs.existsSync(uploadedFile.path)) {
        fs.unlinkSync(uploadedFile.path);
      }

      // Activity log
      await ActivityLog.create({
        userId: req.user._id,
        action: 'UPLOAD',
        target: newFile._id.toString(),
        status: 'SUCCESS',
        ip: req.ip || req.socket.remoteAddress,
      });

      res.status(201).json({
        message: 'File uploaded successfully',
        fileId: newFile._id,
      });
    } catch (error) {
      console.error('[UPLOAD] Error:', error);

      if (
        uploadedFile &&
        fs.existsSync(uploadedFile.path)
      ) {
        fs.unlinkSync(uploadedFile.path);
      }

      res.status(500).json({
        message: 'Upload failed',
      });
    }
  }
);

// ==========================================
// MY FILES
// ==========================================

router.get(
  '/mine',
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    try {
      const files = await File.find({
        owner: req.user?._id,
      }).select(
        '-wrappedAESKeys -iv -authTag'
      );

      res.json(files);
    } catch (error) {
      console.error(error);

      res.status(500).json({
        message: 'Error fetching files',
      });
    }
  }
);

// ==========================================
// SHARED WITH ME
// ==========================================

router.get(
  '/shared-with-me',
  authenticateToken,
  async (req: AuthRequest, res: Response) => {
    try {
      const grants = await AccessGrant.find({
        userId: req.user?._id,
      }).populate(
        'fileId',
        '-wrappedAESKeys -iv -authTag'
      );

      const files = grants
        .map((grant: any) => grant.fileId)
        .filter(Boolean);

      res.json(files);
    } catch (error) {
      console.error(error);

      res.status(500).json({
        message: 'Error fetching shared files',
      });
    }
  }
);

// ==========================================
// SHARE FILE
// ==========================================

router.post(
  '/:id/share',
  authenticateToken,
  async (
    req: AuthRequest,
    res: Response
  ): Promise<void> => {
    try {
      const {
        email,
        permission,
        password,
      } = req.body;

      if (!email || !password) {
        res.status(400).json({
          message: 'Recipient email and password are required',
        });
        return;
      }

      const file = await File.findById(
        req.params.id
      );

      if (
        !file ||
        file.owner.toString() !==
          req.user?._id.toString()
      ) {
        res.status(403).json({
          message: 'Not authorized',
        });
        return;
      }

      const recipient = await User.findOne({
        email,
      });

      if (!recipient) {
        res.status(404).json({
          message: 'Recipient not found',
        });
        return;
      }

      // Prevent duplicate sharing
      const existingKey =
        file.wrappedAESKeys.find(
          (key) =>
            key.userId.toString() ===
            recipient._id.toString()
        );

      if (existingKey) {
        res.status(400).json({
          message:
            'File is already shared with this user',
        });
        return;
      }

      // Get owner's wrapped AES key
      const userWrappedKeyObj =
        file.wrappedAESKeys.find(
          (key) =>
            key.userId.toString() ===
            req.user?._id.toString()
        );

      if (!userWrappedKeyObj) {
        throw new Error(
          'Key not found for owner'
        );
      }

      let privateKeyPEM: string;

      try {
        // Decrypt owner's private RSA key
        privateKeyPEM =
          await decryptPrivateKey(
            req.user!.encryptedPrivateKey,
            req.user!.privateKeySalt,
            req.user!.privateKeyIV,
            req.user!.privateKeyAuthTag,
            password
          );
      } catch {
        res.status(401).json({
          message: 'Invalid password',
        });
        return;
      }

      // Temporarily unwrap AES key
      const aesKey = unwrapKey(
        userWrappedKeyObj.wrappedKey,
        privateKeyPEM
      );

      // Wrap same AES key for recipient
      const newWrappedKey = wrapKey(
        aesKey,
        recipient.rsaPublicKey
      );

      // Add recipient wrapped key
      file.wrappedAESKeys.push({
        userId: recipient._id,
        wrappedKey: newWrappedKey,
      });

      await file.save();

      // Create access grant
      const existingGrant =
        await AccessGrant.findOne({
          fileId: file._id,
          userId: recipient._id,
        });

      if (!existingGrant) {
        await AccessGrant.create({
          fileId: file._id,
          userId: recipient._id,
          permission:
            permission || 'download',
          grantedBy: req.user._id,
        });
      }

      await ActivityLog.create({
        userId: req.user._id,
        action: 'SHARE',
        target: file._id.toString(),
        metadata: {
          recipient: recipient.email,
        },
        status: 'SUCCESS',
        ip:
          req.ip ||
          req.socket.remoteAddress,
      });

      res.json({
        message: 'File shared successfully',
      });
    } catch (error) {
      console.error(
        '[SHARE] Error:',
        error
      );

      res.status(500).json({
        message:
          'Server error during sharing',
      });
    }
  }
);

// ==========================================
// REVOKE FILE ACCESS
// ==========================================

router.delete(
  '/:id/share/:userId',
  authenticateToken,
  async (
    req: AuthRequest,
    res: Response
  ): Promise<void> => {
    try {
      const file = await File.findById(
        req.params.id
      );

      if (
        !file ||
        file.owner.toString() !==
          req.user?._id.toString()
      ) {
        res.status(403).json({
          message: 'Not authorized',
        });
        return;
      }

      // Remove recipient wrapped key
      file.wrappedAESKeys =
        file.wrappedAESKeys.filter(
          (key) =>
            key.userId.toString() !==
            req.params.userId
        );

      await file.save();

      // Remove access grant
      await AccessGrant.deleteOne({
        fileId: file._id,
        userId: req.params.userId,
      });

      await ActivityLog.create({
        userId: req.user._id,
        action: 'REVOKE_ACCESS',
        target: file._id.toString(),
        metadata: {
          revokedUser: req.params.userId,
        },
        status: 'SUCCESS',
        ip:
          req.ip ||
          req.socket.remoteAddress,
      });

      res.json({
        message: 'Access revoked',
      });
    } catch (error) {
      console.error(
        '[REVOKE] Error:',
        error
      );

      res.status(500).json({
        message: 'Server error',
      });
    }
  }
);

// ==========================================
// DOWNLOAD FILE
// ==========================================

router.get(
  '/:id/download',
  authenticateToken,
  async (
    req: AuthRequest,
    res: Response
  ): Promise<void> => {
    let tempOutPath: string | null = null;

    try {
      console.log(
        '[DOWNLOAD] Request received'
      );

      // Get file metadata
      const file = await File.findById(
        req.params.id
      );

      if (!file) {
        res.status(404).json({
          message: 'File not found',
        });
        return;
      }

      console.log(
        '[DOWNLOAD] File metadata loaded'
      );

      // Check ownership
      const isOwner =
        file.owner.toString() ===
        req.user?._id.toString();

      // Check shared access
      if (!isOwner) {
        const grant =
          await AccessGrant.findOne({
            fileId: file._id,
            userId: req.user?._id,
          });

        if (!grant) {
          await ActivityLog.create({
            userId: req.user?._id,
            action: 'ACCESS_DENIED',
            target: file._id.toString(),
            status: 'FAILURE',
            ip:
              req.ip ||
              req.socket.remoteAddress,
          });

          res.status(403).json({
            message: 'Access denied',
          });

          return;
        }

        // Permission check
        if (
          grant.permission !== 'download' &&
          grant.permission !== 'view'
        ) {
          res.status(403).json({
            message:
              'Download permission denied',
          });

          return;
        }
      }

      console.log(
        '[DOWNLOAD] Access permission verified'
      );

      // Password from frontend
      const password =
        req.headers['x-password'] as string;

      if (!password) {
        res.status(401).json({
          message:
            'Password required in X-Password header',
        });

        return;
      }

      // Find AES key wrapped for requesting user
      const userWrappedKeyObj =
        file.wrappedAESKeys.find(
          (key) =>
            key.userId.toString() ===
            req.user?._id.toString()
        );

      if (!userWrappedKeyObj) {
        res.status(403).json({
          message:
            'Key not found for this user',
        });

        return;
      }

      console.log(
        '[DOWNLOAD] Wrapped AES key located'
      );

      // Decrypt user's RSA private key
      let privateKeyPEM: string;

      try {
        console.log(
          '[DOWNLOAD] Encrypted private key decryption started'
        );

        privateKeyPEM =
          await decryptPrivateKey(
            req.user!.encryptedPrivateKey,
            req.user!.privateKeySalt,
            req.user!.privateKeyIV,
            req.user!.privateKeyAuthTag,
            password
          );

        console.log(
          '[DOWNLOAD] Encrypted private key decrypted'
        );
      } catch (error) {
        console.error(
          '[DOWNLOAD] Invalid password:',
          error
        );

        res.status(401).json({
          message: 'Invalid password',
        });

        return;
      }

      // Unwrap AES key
      console.log(
        '[DOWNLOAD] AES key unwrap started'
      );

      const aesKey = unwrapKey(
        userWrappedKeyObj.wrappedKey,
        privateKeyPEM
      );

      console.log(
        '[DOWNLOAD] AES key successfully unwrapped'
      );

      // Locate encrypted file
      const storagePath = path.resolve(
        process.env.STORAGE_PATH ||
          './storage'
      );

      const encryptedFilePath =
        path.join(
          storagePath,
          file.encryptedBlobReference
        );

      if (
        !fs.existsSync(
          encryptedFilePath
        )
      ) {
        res.status(404).json({
          message:
            'Encrypted file not found on disk',
        });

        return;
      }

      // Create temp directory
      const tempDir = path.resolve(
        './temp'
      );

      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, {
          recursive: true,
        });
      }

      // Secure random temp filename
      tempOutPath = path.join(
        tempDir,
        `${uuidv4()}.decrypted`
      );

      // AES-GCM decipher
      const decipher =
        crypto.createDecipheriv(
          'aes-256-gcm',
          aesKey,
          Buffer.from(
            file.iv,
            'base64'
          )
        );

      decipher.setAuthTag(
        Buffer.from(
          file.authTag,
          'base64'
        )
      );

      // SHA256 integrity hash
      const hash =
        crypto.createHash('sha256');

      const { Transform } =
        await import('stream');

      const hashThrough =
        new Transform({
          transform(
            chunk,
            _encoding,
            callback
          ) {
            hash.update(chunk);
            callback(null, chunk);
          },
        });

      const readStream =
        fs.createReadStream(
          encryptedFilePath
        );

      const writeStream =
        fs.createWriteStream(
          tempOutPath
        );

      console.log(
        '[DOWNLOAD] Encrypted file opened'
      );

      console.log(
        '[DOWNLOAD] AES-GCM decryption started'
      );

      const { pipeline } =
        await import('stream/promises');

      // Encrypted -> Decrypt -> Hash -> Temp File
      await pipeline(
        readStream,
        decipher,
        hashThrough,
        writeStream
      );

      console.log(
        '[DOWNLOAD] AES-GCM decryption finished'
      );

      // Calculate integrity hash
      const computedHash =
        hash.digest('hex');

      console.log(
        '[DOWNLOAD] SHA-256 calculation finished'
      );

      // Compare hashes
      if (
        computedHash !==
        file.sha256Hash
      ) {
        console.error(
          '[DOWNLOAD] INTEGRITY FAILURE'
        );

        await ActivityLog.create({
          userId: req.user?._id,
          action: 'INTEGRITY_FAILURE',
          target: file._id.toString(),
          status: 'FAILURE',
          ip:
            req.ip ||
            req.socket.remoteAddress,
        });

        if (
          tempOutPath &&
          fs.existsSync(tempOutPath)
        ) {
          fs.unlinkSync(tempOutPath);
        }

        res.status(500).json({
          message:
            'Integrity check failed. File may be corrupted.',
        });

        return;
      }

      console.log(
        '[DOWNLOAD] Integrity comparison complete'
      );

      // Log successful integrity check
      await ActivityLog.create({
        userId: req.user?._id,
        action: 'INTEGRITY_CHECK',
        target: file._id.toString(),
        status: 'SUCCESS',
        ip:
          req.ip ||
          req.socket.remoteAddress,
      });

      // Log download
      await ActivityLog.create({
        userId: req.user?._id,
        action: 'DOWNLOAD',
        target: file._id.toString(),
        status: 'SUCCESS',
        ip:
          req.ip ||
          req.socket.remoteAddress,
      });

      // ==========================================
      // STREAM FILE TO BROWSER
      // ==========================================

      if (
        !tempOutPath ||
        !fs.existsSync(tempOutPath)
      ) {
        throw new Error(
          'Decrypted temporary file was not created'
        );
      }

      console.log(
        '[DOWNLOAD] Decrypted file ready:',
        tempOutPath
      );

      // Safe filename
      const safeFilename =
        file.filename.replace(
          /["\r\n]/g,
          '_'
        );

      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${safeFilename}"`
      );

      res.setHeader(
        'Content-Type',
        file.mimeType ||
          'application/octet-stream'
      );

      // Get file size
      const stats =
        fs.statSync(tempOutPath);

      res.setHeader(
        'Content-Length',
        stats.size
      );

      console.log(
        '[DOWNLOAD] Streaming file to client'
      );

      const downloadStream =
        fs.createReadStream(tempOutPath);

      let cleanedUp = false;

      const cleanup = () => {
        if (cleanedUp) return;

        cleanedUp = true;

        try {
          if (
            tempOutPath &&
            fs.existsSync(tempOutPath)
          ) {
            fs.unlinkSync(tempOutPath);

            console.log(
              '[DOWNLOAD] Temporary file removed'
            );
          }
        } catch (error) {
          console.error(
            '[DOWNLOAD] Cleanup error:',
            error
          );
        }
      };

      downloadStream.on(
        'error',
        (error) => {
          console.error(
            '[DOWNLOAD] Stream error:',
            error
          );

          cleanup();

          if (!res.headersSent) {
            res.status(500).json({
              message:
                'Failed to stream decrypted file',
            });
          }
        }
      );

      downloadStream.on(
        'end',
        () => {
          console.log(
            '[DOWNLOAD] File stream completed'
          );
        }
      );

      res.on('finish', () => {
        console.log(
          '[DOWNLOAD] Response finished'
        );

        cleanup();
      });

      res.on('close', () => {
        cleanup();
      });

      // Pipe decrypted file to browser
      downloadStream.pipe(res);

    } catch (error: any) {
      console.error(
        '[DOWNLOAD] Error:',
        error
      );

      if (
        tempOutPath &&
        fs.existsSync(tempOutPath)
      ) {
        try {
          fs.unlinkSync(tempOutPath);
        } catch {
          // Ignore cleanup errors
        }
      }

      if (!res.headersSent) {
        res.status(500).json({
          message:
            'Download failed: ' +
            (error.message ||
              'Unknown error'),
        });
      }
    }
  }
);

// ==========================================
// INTEGRITY ENDPOINT
// ==========================================

router.get(
  '/:id/integrity',
  authenticateToken,
  async (
    req: AuthRequest,
    res: Response
  ): Promise<void> => {
    try {
      const file = await File.findById(
        req.params.id
      );

      if (!file) {
        res.status(404).json({
          message: 'File not found',
        });

        return;
      }

      res.json({
        message:
          'Integrity verification is performed during secure download.',
        fileId: file._id,
        algorithm: 'SHA-256',
      });
    } catch (error) {
      res.status(500).json({
        message:
          'Integrity check failed',
      });
    }
  }
);

export default router;